<template>
  <BaseOptionQuestion tag-name="ol" />
</template>

<script setup>
import BaseOptionQuestion from './BaseOptionQuestion.vue';
</script>