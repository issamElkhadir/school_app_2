<template>
  <div class="w-75">
    <span class="py-1 w-100 d-inline-block text-muted border-dotted-bottom">
      {{ $t('Long Answer Text') }}
    </span>
  </div>
</template>

<script setup>

</script>