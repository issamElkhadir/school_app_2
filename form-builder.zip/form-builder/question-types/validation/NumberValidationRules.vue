<template>
  <div>
    Number Validation Rules
  </div>
</template>